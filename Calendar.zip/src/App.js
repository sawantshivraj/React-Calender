import './App.css'
import CalendarPage from './Components/CalendarPage'

function App() {
  return (
    <>
      <CalendarPage />
    </>
  )
}

export default App
