import React, { useState } from 'react'
import './CalendarPage.css'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'

export default function CalendarPage() {
  const [date, setDate] = useState(new Date())
  const onChange = (date) => {
    setDate(date)
  }
  const [inputTime, setTime] = useState('1 PM')
  const click = (e) => {
    setTime(e.target.value)
    removeActiveClasses()
    e.target.classList.add('active')
  }

  function removeActiveClasses() {
    const timebtns = document.querySelectorAll('.timebtn')
    timebtns.forEach((timebtn) => {
      timebtn.classList.remove('active')
    })
  }

  return (
    <>
      <div className='container shadow  bg-body rounded'>
        <div className='row'>
          <div className='col-lg-6 col-md-6 col-12 con1 '>
            <Calendar
              className='calen shadow bg-body rounded'
              onChange={onChange}
              value={date}
            />
          </div>
          <div className='col-lg-6 col-md-6 col-12 con2'>
            <div className='row '>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='9 AM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='10 AM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='11 AM'
                  onClick={click}
                />
              </div>
            </div>
            <div className='row'>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='12 PM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn active shadow-sm   rounded'
                  value='1 PM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='2 PM'
                  onClick={click}
                />
              </div>
            </div>
            <div className='row'>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='3 PM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='4 PM'
                  onClick={click}
                />
              </div>
              <div className='col-4 '>
                <input
                  type='button'
                  className='btn btn-light timebtn shadow-sm  rounded'
                  value='5 PM'
                  onClick={click}
                />
              </div>
            </div>
          </div>
        </div>
        <div className='row outputrow'>
          <div className='col-lg-8 col-xl-6 col-10 output shadow  bg-body rounded'>
            <span id='output'>
              Selected Time: {date.toDateString()}, {inputTime}
            </span>
          </div>
        </div>
      </div>
    </>
  )
}
